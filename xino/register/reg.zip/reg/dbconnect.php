<?php
$con = mysqli_connect("localhost","root","","xinoreg");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
 		//error_reporting(0); //comment to be removed at the end

?>

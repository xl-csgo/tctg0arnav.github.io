<?php
session_start(); 
require_once('dbconnect.php');

if (isset($_POST['submit'])) {
	$school_name = $_SESSION['school'];
	$query = "SELECT * FROM invite WHERE school=\"".$school_name."\"";
	$result = mysqli_query($con,$query);
	while ($row = mysqli_fetch_assoc($result)) {
		$school_email = $row['school_email'];
	}

	function trimStr($con, $string) {
		return mysqli_real_escape_string($con, $string);
	}

	$teachin_name = trimStr($con,$_POST['teachin_name']);
	$teachin_mail = trimStr($con,$_POST['teachin_mail']);
	$teachin_phone = trimStr($con,$_POST['teachin_phone']);
	$studin_name = trimStr($con,$_POST['studin_name']);
	$studin_mail = trimStr($con,$_POST['studin_mail']);
	$studin_phone = trimStr($con,$_POST['studin_phone']);
	$quiz1 = $_POST['quiz1'];
	$quiz2 = $_POST['quiz2'];
	$quiz = [$quiz1,$quiz2];
	$quiz = json_encode($quiz);
	$cross1 = $_POST['cross1'];
	$cross2 = $_POST['cross2'];
	$crossword = [$cross1,$cross2];
	$crossword = json_encode($crossword);
	$hack1 = $_POST['hack1'];
	$hack2 = $_POST['hack2'];
	$hack3 = $_POST['hack3'];
	$hack4 = $_POST['hack4'];
	$hackathon = [$hack1,$hack2,$hack3,$hack4];
	$hackathon = json_encode($hackathon);
	$surp1 = $_POST['surp1'];
	$surp2 = $_POST['surp2'];
	$surprise = [$surp1,$surp2];
	$surprise = json_encode($surprise);
	$gd = $_POST['gd'];
	$group_discussion = [$gd];
	$group_discussion = json_encode($group_discussion);
	$photo = $_POST['photo'];
	$photography = [$photo];
	$photography = json_encode($photography);
	$insolvent1 = $_POST['insolvent1'];
	$insolvent2 = $_POST['insolvent2'];
	$insolvent = [$insolvent1,$insolvent2];
	$insolvent = json_encode($insolvent);
	$outcry1 = $_POST['outcry1'];
	$outcry2 = $_POST['outcry2'];
	$outcry = [$outcry1,$outcry2];
	$outcry = json_encode($outcry);
	$turnaround1 = $_POST['turnaround1'];
	$turnaround2 = $_POST['turnaround2'];
	$turnaround = [$turnaround1,$turnaround2];
	$turnaround = json_encode($turnaround);
	$bse1 = $_POST['bse1'];
	$bse2 = $_POST['bse2'];
	$bse = [$bse1,$bse2];
	$bse = json_encode($bse);
	$realtor1 = $_POST['realtor1'];
	$realtor2 = $_POST['realtor2'];
	$realtor = [$realtor1,$realtor2];
	$realtor = json_encode($realtor);

	// echo $school_name . "<br>" . $school_email . "<br>" . $teachin_name . "<br>" . $teachin_mail . "<br>" . $teachin_phone . "<br>" . $studin_name . "<br>" . $studin_mail . "<br>" . $studin_phone;
	
	// echo $quiz . "<br>" . $crossword . "<br>" . $hackathon . "<br>" . $surprise . "<br>" . $gaming . "<br>" . $group_discussion . "<br>" . $photography;
	
	if (mysqli_query($con, "INSERT INTO schools (school_name,school_email,teachin_name,teachin_email,teachin_phone,studin_name,studin_email,studin_phone,quiz,crossword,hackathon,surprise,gd,photography,insolvent,outcry,turnaround,bse,realtor) VALUES ('$school_name', '$school_email','$teachin_name', '$teachin_mail', '$teachin_phone', '$studin_name', '$studin_mail', '$studin_phone', '$quiz', '$crossword', '$hackathon', '$surprise', '$group_discussion', '$photography', '$insolvent', '$outcry', '$turnaround', '$bse', '$realtor')")) {
		
	$sql = "UPDATE invite SET reg_status=1 WHERE school='".$_SESSION['school']."'";
		if(mysqli_query($con, $sql)) {
			// echo "success1 | ";
		}
		else {
			// echo "error1: " . mysql_error();
		}
		session_destroy();
		header("location:success.php");
		//echo "success";
		
		
	}
	else {
		//echo "Error: " . mysql_error();
		header("location: register.php?m=2");
	}
	
}

?>
<?php
session_start();
if(isset($_SESSION['admin'])) {
	if($_SESSION['admin']!=1) {
		header("Location: ../index.php");
	}
}
else {
	header("Location: ../index.php");
} 
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center>
<br>
<h1>Schools</h1>
<br><br>
<table border="1" cellpadding="20" cellspacing="0">
	<tr>
		<th>S. No.</th>
		<th>School Name</th>
		<th>School Email</th>
        <th>Invitation Code</th>
        <th>Status</th>
	</tr>
<?php
require_once('../dbconnect.php');
$query = "SELECT * FROM invite";
$result = mysqli_query($con,$query);
$i=1;
while ($row = mysqli_fetch_assoc($result)) {
	$id=$row['id'];
	$school = $row['school'];
	$school_email = $row['school_email'];
	$invite_code = $row['invite_code'];
    if($row['reg_status']==1) {
        $status="Registered";
    }
    else {
        $status="Not Registered";
    }

	echo "<tr>
		  <td>{$i}</td>
		  <td>{$school}</td>
		  <td>{$school_email}</td>
          <td>{$invite_code}</td>
          <td>{$status}</td>
		  <tr>";
$i++;
}

?>
</table>
<br><br>
<a href="index.php">&larr; Go Back</a>
</center>
<link rel="stylesheet" type="text/css" href="../style.css">
<div class="space-large"></div>
</body>
</html>
<?php
// require 'sendgrid-php/sendgrid-php.php'; // If you're using Composer (recommended)
// Comment out the above line if not using Composer
require("../sendgrid-php/sendgrid-php.php");
// If not using Composer, uncomment the above line and
// download sendgrid-php.zip from the latest release here,
// replacing <PATH TO> with the path to the sendgrid-php.php file,
// which is included in the download:
// https://github.com/sendgrid/sendgrid-php/releases
$email = new \SendGrid\Mail\Mail(); 
$email->setFrom("mail@xino.in", "XINO");
$email->addTo(
    "sayamkanwar616@gmail.com", 
    "Sayam Kanwar",
    [ 
        "-invite_code-" => "SAYAMKANWAR_CODE123"
    ],
    0
);
// $email->addTo(
//     "test+test3@example.com", 
//     "Example User3",
//     [ 
//         "-name-" => "Example User 3",
//         "-city-" => "Redwood City"
//     ],
//     2
// );
$email->setTemplateId("f93961a3-3c01-4ec5-b2e0-2fd02b0f606f");
$sendgrid = new \SendGrid("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");
try {
    $response = $sendgrid->send($email);
    print $response->statusCode() . "\n";
    print_r($response->headers());
    print $response->body() . "\n";
} catch (Exception $e) {
    echo 'Caught exception: '.  $e->getMessage(). "\n";
}

?>

